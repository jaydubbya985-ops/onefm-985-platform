import{K as r,O as t}from"./index-DeB4MILB.js";var a=t();const e=r(a);export{e as R,a as r};
